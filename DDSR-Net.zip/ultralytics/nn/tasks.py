from .AddModules import *
import contextlib
import pickle
import re
import types
from copy import deepcopy
from pathlib import Path

import torch
import torch.nn as nn

from ultralytics.nn.modules import Concat, Conv, RepConv, RepC3, RTDETRDecoder, DeFE
from ultralytics.utils import DEFAULT_CFG_DICT, DEFAULT_CFG_KEYS, LOGGER, colorstr, emojis, yaml_load
from ultralytics.utils.checks import check_requirements, check_suffix, check_yaml
from ultralytics.utils.ops import make_divisible
from ultralytics.utils.plotting import feature_visualization
from ultralytics.utils.torch_utils import (
    fuse_conv_and_bn, fuse_deconv_and_bn, initialize_weights, intersect_dicts, model_info, scale_img, time_sync,
)

try:
    import thop
except ImportError:
    thop = None

class BaseModel(nn.Module):
    pass

    def forward(self, x, *args, **kwargs):
        pass

        if isinstance(x, dict):
            return self.loss(x, *args, **kwargs)
        return self.predict(x, *args, **kwargs)

    def predict(self, x, profile=False, visualize=False, augment=False, embed=None):
        pass

        if augment:
            return self._predict_augment(x)
        return self._predict_once(x, profile, visualize, embed)

    def _predict_once(self, x, profile=False, visualize=False, embed=None):
        pass

        y, dt, embeddings = [], [], []
        for m in self.model:
            if m.f != -1:
                x = y[m.f] if isinstance(m.f, int) else [x if j == -1 else y[j] for j in m.f]
            if profile:
                self._profile_one_layer(m, x, dt)
            x = m(x)
            y.append(x if m.i in self.save else None)
            if visualize:
                feature_visualization(x, m.type, m.i, save_dir=visualize)
            if embed and m.i in embed:
                embeddings.append(nn.functional.adaptive_avg_pool2d(x, (1, 1)).squeeze(-1).squeeze(-1))
                if m.i == max(embed):
                    return torch.unbind(torch.cat(embeddings, 1), dim=0)
        return x

    def _predict_augment(self, x):
        pass
        LOGGER.warning(
            f"WARNING ⚠️ {self.__class__.__name__} does not support 'augment=True' prediction. "
            f"Reverting to single-scale prediction."
        )
        return self._predict_once(x)

    def _profile_one_layer(self, m, x, dt):
        pass

        c = m == self.model[-1] and isinstance(x, list)
        flops = thop.profile(m, inputs=[x.copy() if c else x], verbose=False)[0] / 1e9 * 2 if thop else 0
        t = time_sync()
        for _ in range(10):
            m(x.copy() if c else x)
        dt.append((time_sync() - t) * 100)
        if m == self.model[0]:
            LOGGER.info(f"{'time (ms)':>10s} {'GFLOPs':>10s} {'params':>10s}  module")
        LOGGER.info(f"{dt[-1]:10.2f} {flops:10.2f} {m.np:10.0f}  {m.type}")
        if c:
            LOGGER.info(f"{sum(dt):10.2f} {'-':>10s} {'-':>10s}  Total")

    def fuse(self, verbose=True):
        if not self.is_fused():
            for module in self.model.modules():
                if isinstance(module, Conv) and hasattr(module, "bn"):
                    module.conv = fuse_conv_and_bn(module.conv, module.bn)
                    delattr(module, "bn")
                    module.forward = module.forward_fuse
                if isinstance(module, RepConv):
                    module.fuse_convs()
                    module.forward = module.forward_fuse
            self.info(verbose=verbose)
        return self

    def is_fused(self, thresh=10):
        pass

        bn = tuple(v for k, v in nn.__dict__.items() if "Norm" in k)
        return sum(isinstance(v, bn) for v in self.modules()) < thresh

    def info(self, detailed=False, verbose=True, imgsz=640):
        pass

        return model_info(self, detailed=detailed, verbose=verbose, imgsz=imgsz)

    def _apply(self, fn):
        return super()._apply(fn)

    def load(self, weights, verbose=True):
        pass

        model = weights["model"] if isinstance(weights, dict) else weights
        csd = model.float().state_dict()
        csd = intersect_dicts(csd, self.state_dict())
        self.load_state_dict(csd, strict=False)
        if verbose:
            LOGGER.info(f"Transferred {len(csd)}/{len(self.model.state_dict())} items from pretrained weights")

    def loss(self, batch, preds=None):
        pass

        if getattr(self, "criterion", None) is None:
            self.criterion = self.init_criterion()

        preds = self.forward(batch["img"]) if preds is None else preds
        return self.criterion(preds, batch)

    def init_criterion(self):
        pass
        raise NotImplementedError("compute_loss() needs to be implemented by task heads")

class DetectionModel(BaseModel):
    pass

    def __init__(self, cfg="p2.yaml", ch=6, nc=None, verbose=True):
        super().__init__()
        self.yaml = cfg if isinstance(cfg, dict) else yaml_model_load(cfg)
        ch = self.yaml["ch"] = self.yaml.get("ch", ch)
        if nc and nc != self.yaml["nc"]:
            LOGGER.info(f"Overriding model.yaml nc={self.yaml['nc']} with nc={nc}")
            self.yaml["nc"] = nc
        self.model, self.save = parse_model(deepcopy(self.yaml), ch=ch, verbose=verbose)
        self.names = {i: f"{i}" for i in range(self.yaml["nc"])}
        self.inplace = self.yaml.get("inplace", True)
        self.end2end = getattr(self.model[-1], "end2end", False)
        self.stride = torch.Tensor([32])
        initialize_weights(self)
        if verbose:
            self.info()
            LOGGER.info("")

    def _predict_augment(self, x):
        pass
        if getattr(self, "end2end", False) or self.__class__.__name__ != "DetectionModel":
            LOGGER.warning("WARNING ⚠️ Model does not support 'augment=True', reverting to single-scale prediction.")
            return self._predict_once(x)
        img_size = x.shape[-2:]
        s = [1, 0.83, 0.67]
        f = [None, 3, None]
        y = []
        for si, fi in zip(s, f):
            xi = scale_img(x.flip(fi) if fi else x, si, gs=int(self.stride.max()))
            yi = super().predict(xi)[0]
            yi = self._descale_pred(yi, fi, si, img_size)
            y.append(yi)
        y = self._clip_augmented(y)
        return torch.cat(y, -1), None

    @staticmethod
    def _descale_pred(p, flips, scale, img_size, dim=1):
        pass
        p[:, :4] /= scale
        x, y, wh, cls = p.split((1, 1, 2, p.shape[dim] - 4), dim)
        if flips == 2:
            y = img_size[0] - y
        elif flips == 3:
            x = img_size[1] - x
        return torch.cat((x, y, wh, cls), dim)

    def _clip_augmented(self, y):
        pass
        nl = self.model[-1].nl
        g = sum(4**x for x in range(nl))
        e = 1
        i = (y[0].shape[-1] // g) * sum(4**x for x in range(e))
        y[0] = y[0][..., :-i]
        i = (y[-1].shape[-1] // g) * sum(4 ** (nl - 1 - x) for x in range(e))
        y[-1] = y[-1][..., i:]
        return y

    def init_criterion(self):
        raise NotImplementedError()





class RTDETRDetectionModel(DetectionModel):
    pass

    def __init__(self, cfg="p2.yaml", ch=6, nc=None, verbose=True):
        super().__init__(cfg=cfg, ch=ch, nc=nc, verbose=verbose)
        self.nc = self.yaml["nc"]
        if not self.yaml.get("ddsr", False):
            raise ValueError("DDSR model configuration is required")
        if self.yaml.get("query_mode", "paper") != "paper":
            raise ValueError("DQI requires the paper query mode")
        if self.yaml.get("density_l1", "sum") != "sum":
            raise ValueError("Density L1 reduction must be sum")
        if self.yaml.get("query_warmup_steps", 0) or self.yaml.get("min_queries", 1) != 1:
            raise ValueError("DQI requires one minimum query and no warmup")
        for module in self.model.modules():
            if isinstance(module, DeFE):
                module.configure_queries("paper", 1, 0)

    def init_criterion(self):
        pass
        from ultralytics.models.utils.ddsr_loss import DDSRLoss
        return DDSRLoss(self.nc, self.yaml.get("density_sigma", 5.0),
                        self.yaml.get("density_normalization", "mass"),
                        self.yaml.get("query_shortage", "warn"),
                        self.yaml.get("match_class_weight", 1.0), self.yaml.get('density_l1','sum'),
                        self.yaml.get('diagnostics_interval',0), self.yaml.get('density_foreground_threshold',.1))

    def loss(self, batch, preds=None):
        if getattr(self, "criterion", None) is None:
            self.criterion = self.init_criterion()
        images = batch["img"]
        if self.training and preds is None and self.yaml.get('amm_probability',0):
            from ultralytics.nn.modules.ddsr_training import asymmetric_modality_masking
            images = asymmetric_modality_masking(images, probability=self.yaml['amm_probability'])
        prediction = self.predict(images) if preds is None else preds
        output = prediction if self.training else prediction[1]
        components = self.criterion(output, batch)
        self.last_density_loss = components["loss_density"].detach()
        return sum(components.values()), torch.stack([components[k].detach() for k in
                ("loss_giou", "loss_class", "loss_bbox", "loss_density")])

    def predict(self, x, profile=False, visualize=False, batch=None, augment=False, embed=None):
        pass

        if profile or visualize or embed:
            raise NotImplementedError("Use forward hooks for dictionary-valued DQI outputs")
        image_size = x.shape[-2:]
        outputs = []
        for module in self.model[:-1]:
            if module.f != -1:
                inputs = outputs[module.f] if isinstance(module.f, int) else [
                    x if source == -1 else outputs[source] for source in module.f]
            else:
                inputs = x
            x = module(inputs, image_size=image_size) if isinstance(module, DeFE) else module(inputs)
            outputs.append(x if module.i in self.save else None)
        head = self.model[-1]
        return head([outputs[source] for source in head.f], batch=batch)


class Ensemble(nn.ModuleList):
    pass

    def __init__(self):
        pass
        super().__init__()

    def forward(self, x, augment=False, profile=False, visualize=False):
        pass
        y = [module(x, augment, profile, visualize)[0] for module in self]

        y = torch.cat(y, 2)
        return y, None

@contextlib.contextmanager
def temporary_modules(modules=None, attributes=None):
    pass

    if modules is None:
        modules = {}
    if attributes is None:
        attributes = {}
    import sys
    from importlib import import_module

    try:

        for old, new in attributes.items():
            old_module, old_attr = old.rsplit(".", 1)
            new_module, new_attr = new.rsplit(".", 1)
            setattr(import_module(old_module), old_attr, getattr(import_module(new_module), new_attr))

        for old, new in modules.items():
            sys.modules[old] = import_module(new)

        yield
    finally:

        for old in modules:
            if old in sys.modules:
                del sys.modules[old]

class SafeClass:
    pass

    def __init__(self, *args, **kwargs):
        pass
        pass

    def __call__(self, *args, **kwargs):
        pass
        pass

class SafeUnpickler(pickle.Unpickler):
    pass

    def find_class(self, module, name):
        pass
        safe_modules = (
            "torch",
            "collections",
            "collections.abc",
            "builtins",
            "math",
            "numpy",

        )
        if module in safe_modules:
            return super().find_class(module, name)
        else:
            return SafeClass

def torch_safe_load(weight, safe_only=False):
    pass

    from ultralytics.utils.downloads import attempt_download_asset

    check_suffix(file=weight, suffix=".pt")
    file = attempt_download_asset(weight)
    try:
        with temporary_modules(
            modules={
                "ultralytics.yolo.utils": "ultralytics.utils",
                "ultralytics.yolo.v8": "ultralytics.models.yolo",
                "ultralytics.yolo.data": "ultralytics.data",
            },
            attributes={
                "ultralytics.nn.modules.block.Silence": "torch.nn.Identity",
                "ultralytics.nn.tasks.YOLOv10DetectionModel": "ultralytics.nn.tasks.DetectionModel",
            },
        ):
            if safe_only:

                safe_pickle = types.ModuleType("safe_pickle")
                safe_pickle.Unpickler = SafeUnpickler
                safe_pickle.load = lambda file_obj: SafeUnpickler(file_obj).load()
                with open(file, "rb") as f:
                    ckpt = torch.load(f, pickle_module=safe_pickle)
            else:
                ckpt = torch.load(file, map_location="cpu")

    except ModuleNotFoundError as e:
        if e.name == "models":
            raise TypeError(
                emojis(
                    f"ERROR ❌️ {weight} appears to be an Ultralytics YOLOv5 model originally trained "
                    f"with https://github.com/ultralytics/yolov5.\nThis model is NOT forwards compatible with "
                    f"YOLOv8 at https://github.com/ultralytics/ultralytics."
                    f"\nRecommend fixes are to train a new model using the latest 'ultralytics' package or to "
                    f"run a command with an official Ultralytics model, i.e. 'yolo predict model=yolov8n.pt'"
                )
            ) from e
        LOGGER.warning(
            f"WARNING ⚠️ {weight} appears to require '{e.name}', which is not in Ultralytics requirements."
            f"\nAutoInstall will run now for '{e.name}' but this feature will be removed in the future."
            f"\nRecommend fixes are to train a new model using the latest 'ultralytics' package or to "
            f"run a command with an official Ultralytics model, i.e. 'yolo predict model=yolov8n.pt'"
        )
        check_requirements(e.name)
        ckpt = torch.load(file, map_location="cpu")

    if not isinstance(ckpt, dict):

        LOGGER.warning(
            f"WARNING ⚠️ The file '{weight}' appears to be improperly saved or formatted. "
            f"For optimal results, use model.save('filename.pt') to correctly save YOLO models."
        )
        ckpt = {"model": ckpt.model}

    return ckpt, file

def attempt_load_weights(weights, device=None, inplace=True, fuse=False):
    pass
    ensemble = Ensemble()
    for w in weights if isinstance(weights, list) else [weights]:
        ckpt, w = torch_safe_load(w)
        args = {**DEFAULT_CFG_DICT, **ckpt["train_args"]} if "train_args" in ckpt else None
        model = (ckpt.get("ema") or ckpt["model"]).to(device).float()

        model.args = args
        model.pt_path = w
        model.task = guess_model_task(model)
        if not hasattr(model, "stride"):
            model.stride = torch.tensor([32.0])

        ensemble.append(model.fuse().eval() if fuse and hasattr(model, "fuse") else model.eval())

    for m in ensemble.modules():
        if hasattr(m, "inplace"):
            m.inplace = inplace
        elif isinstance(m, nn.Upsample) and not hasattr(m, "recompute_scale_factor"):
            m.recompute_scale_factor = None

    if len(ensemble) == 1:
        return ensemble[-1]

    LOGGER.info(f"Ensemble created with {weights}\n")
    for k in "names", "nc", "yaml":
        setattr(ensemble, k, getattr(ensemble[0], k))
    ensemble.stride = ensemble[int(torch.argmax(torch.tensor([m.stride.max() for m in ensemble])))].stride
    assert all(ensemble[0].nc == m.nc for m in ensemble), f"Models differ in class counts {[m.nc for m in ensemble]}"
    return ensemble

def attempt_load_one_weight(weight, device=None, inplace=True, fuse=False):
    pass
    ckpt, weight = torch_safe_load(weight)
    args = {**DEFAULT_CFG_DICT, **(ckpt.get("train_args", {}))}
    model = (ckpt.get("ema") or ckpt["model"]).to(device).float()

    model.args = {k: v for k, v in args.items() if k in DEFAULT_CFG_KEYS}
    model.pt_path = weight
    model.task = guess_model_task(model)
    if not hasattr(model, "stride"):
        model.stride = torch.tensor([32.0])

    model = model.fuse().eval() if fuse and hasattr(model, "fuse") else model.eval()

    for m in model.modules():
        if hasattr(m, "inplace"):
            m.inplace = inplace
        elif isinstance(m, nn.Upsample) and not hasattr(m, "recompute_scale_factor"):
            m.recompute_scale_factor = None

    return model, ckpt

def parse_model(d, ch, verbose=True):
    import ast
    nc = d.get("nc")
    scales = d.get("scales")
    depth, width = d.get("depth_multiple", 1.0), d.get("width_multiple", 1.0)
    max_channels = float("inf")
    if scales:
        scale = d.get("scale") or next(iter(scales))
        depth, width, max_channels = scales[scale]
    if d.get("activation"):
        Conv.default_act = eval(d["activation"])
    if verbose:
        LOGGER.info(f"\n{'':>3}{'from':>20}{'n':>3}{'params':>10}  {'module':<45}{'arguments':<30}")
    ch = [ch]
    layers, save = [], []
    for i, (f, n, name, args) in enumerate(d["backbone"] + d["head"]):
        m = getattr(nn, name[3:]) if name.startswith("nn.") else globals()[name]
        for j, a in enumerate(args):
            if isinstance(a, str):
                try:
                    args[j] = locals()[a] if a in locals() else ast.literal_eval(a)
                except ValueError:
                    pass
        n = n_ = max(round(n * depth), 1) if n > 1 else n
        if m in {Conv, RepC3, Blocks, ConvNormLayer}:
            c1, c2 = ch[f], args[0]
            if c2 != nc:
                c2 = make_divisible(min(c2, max_channels) * width, 8)
            args = [c1, c2, *args[1:]]
            if m in {RepC3, Blocks}:
                args.insert(2, n)
                n = 1
        elif m is Multiin:
            c2 = ch[f] // 2
        elif m is Concat:
            c2 = sum(ch[x] for x in f)
        elif m is RTDETRDecoder:
            args[2] = d.get("query_capacity", args[2])
            args.insert(1, [ch[x] for x in f])
            c2 = ch[f[-1]]
        elif m is DeFE:
            args[0] = d.get("query_capacity", args[0])
            c2 = ch[f] - 1
            args = [c2, *args]
        elif m is SpatialDualAttention:
            if ch[f[0]] != ch[f[1]]:
                raise ValueError("FDA requires equal channels from both streams")
            c2 = ch[f[0]] + 1
            args = [ch[f[0]], *args]
        else:
            c2 = ch[f]
        module = nn.Sequential(*(m(*args) for _ in range(n))) if n > 1 else m(*args)
        typ = str(m)[8:-2].replace("__main__.", "")
        module.np = sum(x.numel() for x in module.parameters())
        module.i, module.f, module.type = i, f, typ
        if verbose:
            LOGGER.info(f"{i:>3}{str(f):>20}{n_:>3}{module.np:10.0f}  {typ:<45}{str(args):<30}")
        save.extend(x % i for x in ([f] if isinstance(f, int) else f) if x != -1)
        layers.append(module)
        if i == 0:
            ch = []
        ch.append(c2)
    return nn.Sequential(*layers), sorted(save)

def yaml_model_load(path):
    pass
    path = Path(path)
    if path.stem in (f"yolov{d}{x}6" for x in "nsmlx" for d in (5, 8)):
        new_stem = re.sub(r"(\d+)([nslmx])6(.+)?$", r"\1\2-p6\3", path.stem)
        LOGGER.warning(f"WARNING ⚠️ Ultralytics YOLO P6 models now use -p6 suffix. Renaming {path.stem} to {new_stem}.")
        path = path.with_name(new_stem + path.suffix)

    unified_path = re.sub(r"(\d+)([nslmx])(.+)?$", r"\1\3", str(path))
    yaml_file = check_yaml(unified_path, hard=False) or check_yaml(path)
    d = yaml_load(yaml_file)
    d["scale"] = guess_model_scale(path)
    d["yaml_file"] = str(path)
    return d

def guess_model_scale(model_path):
    pass

    try:
        return re.search(r"yolo[v]?\d+([nslmx])", Path(model_path).stem).group(1)
    except AttributeError:
        return ""

def guess_model_task(model):
    return "detect"
