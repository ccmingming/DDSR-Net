from pathlib import Path
import torch
import torch.nn as nn
from ultralytics.utils import yaml_load
from ultralytics.utils.checks import check_yaml


def check_class_names(names):
    if isinstance(names, list):
        names = dict(enumerate(names))
    if isinstance(names, dict):
        names = {int(k): str(v) for k, v in names.items()}
        if names and (min(names) < 0 or max(names) >= len(names)):
            raise KeyError("Class indices must be consecutive and start from zero")
    return names


def default_class_names(data=None):
    if data:
        try:
            return yaml_load(check_yaml(data))["names"]
        except Exception:
            pass
    return {i: f"class{i}" for i in range(999)}


class AutoBackend(nn.Module):
    @torch.no_grad()
    def __init__(self, weights="model.pt", device=torch.device("cpu"), dnn=False,
                 data=None, fp16=False, batch=1, fuse=True, verbose=True):
        super().__init__()
        if dnn:
            raise ValueError("Only PyTorch checkpoints are supported")
        if isinstance(weights, nn.Module):
            model = weights.to(device)
            if fuse:
                model = model.fuse(verbose=verbose)
        else:
            from ultralytics.nn.tasks import attempt_load_weights
            model = attempt_load_weights(weights, device=device, inplace=True, fuse=fuse)
        self.device = device
        self.fp16 = fp16
        self.model = model.half() if fp16 else model.float()
        self.model.eval()
        self.pt = True
        self.jit = False
        self.engine = False
        self.triton = False
        self.nn_module = True
        self.nhwc = False
        self.batch_size = batch
        self.stride = max(int(model.stride.max()), 32)
        self.names = check_class_names(model.module.names if hasattr(model, "module") else model.names)
        self.metadata = {}
        for parameter in self.model.parameters():
            parameter.requires_grad = False

    def forward(self, im, augment=False, visualize=False, embed=None):
        if self.fp16 and im.dtype != torch.float16:
            im = im.half()
        return self.model(im, augment=augment, visualize=visualize, embed=embed)

    def warmup(self, imgsz=(1, 6, 640, 640)):
        if self.device.type != "cpu":
            im = torch.empty(*imgsz, dtype=torch.half if self.fp16 else torch.float, device=self.device)
            self.forward(im)
