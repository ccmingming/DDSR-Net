import torch

def asymmetric_modality_masking(images, probability=0.3, area_range=(0.02, 0.20),
                                aspect_range=(0.5, 2.0)):
    pass

    if images.ndim != 4 or images.shape[1] != 6:
        raise ValueError('AMM expects paired six-channel images')
    if torch.rand((), device=images.device).item() >= probability:
        return images
    result = images.clone()
    h, w = images.shape[-2:]
    for index in range(len(images)):
        area = torch.empty((), device=images.device).uniform_(*area_range).item() * h * w
        aspect = torch.empty((), device=images.device).uniform_(*aspect_range).item()
        rh = max(1, min(h, round((area / aspect)**0.5)))
        rw = max(1, min(w, round((area * aspect)**0.5)))
        y = int(torch.randint(h - rh + 1, (), device=images.device))
        x = int(torch.randint(w - rw + 1, (), device=images.device))
        modality = int(torch.randint(2, (), device=images.device))
        region = result[index, modality * 3:(modality + 1) * 3, y:y + rh, x:x + rw]
        if modality == 0:
            region.copy_((torch.randn_like(region) * (15.0 / 255) + 240.0 / 255).clamp(0, 1))
        else:
            region.copy_(region.mean(dim=(-1, -2), keepdim=True).expand_as(region).clone())
    return result

@torch.no_grad()
def load_imagenet_stages(model, source=None):
    pass

    from ultralytics.utils import LOGGER
    if source:
        state = torch.load(source, map_location='cpu', weights_only=True)
        state = state.get('state_dict',state)
    else:
        from torchvision.models import ResNet18_Weights
        state = ResNet18_Weights.IMAGENET1K_V1.get_state_dict(progress=True,check_hash=True)
    loaded = 0

    def copy_layer(layer, conv_key, bn_key):
        nonlocal loaded
        if conv_key not in state or state[conv_key].shape != layer.conv.weight.shape:
            raise ValueError('ImageNet stage tensor missing or incompatible: '+conv_key)
        layer.conv.weight.copy_(state[conv_key])
        if layer.conv.bias is not None:
            layer.conv.bias.zero_()
        bn_state = {}
        for key, expected in layer.norm.state_dict().items():
            source_key = bn_key+'.'+key
            if source_key not in state:

                if key == 'num_batches_tracked':
                    bn_state[key] = torch.zeros_like(expected)
                    continue
                raise ValueError('ImageNet BatchNorm tensor missing: '+source_key)
            value = state[source_key]
            if value.shape != expected.shape:
                raise ValueError('ImageNet BatchNorm tensor incompatible: '+source_key)
            bn_state[key] = value
        layer.norm.load_state_dict(bn_state,strict=True)
        loaded += 1 + sum(bn_key+'.'+key in state for key in bn_state)

    for stream in ((6,7,8,9),(15,16,17,18)):
        for stage,index in enumerate(stream,1):
            for number,block in enumerate(model.model[index].blocks):
                prefix = 'layer%d.%d.' % (stage,number)
                copy_layer(block.branch2a,prefix+'conv1.weight',prefix+'bn1')
                copy_layer(block.branch2b,prefix+'conv2.weight',prefix+'bn2')
                if not block.shortcut:
                    if prefix+'downsample.0.weight' in state:
                        copy_layer(block.short,prefix+'downsample.0.weight',prefix+'downsample.1')
                    else:

                        torch.nn.init.dirac_(block.short.conv.weight)
                        if block.short.conv.bias is not None:
                            block.short.conv.bias.zero_()
                        block.short.norm.weight.fill_((1+block.short.norm.eps)**.5)
                        block.short.norm.bias.zero_()
                        block.short.norm.running_mean.zero_()
                        block.short.norm.running_var.fill_(1)
    model.imagenet_stages_loaded = True
    LOGGER.info('DDSR loaded %d ImageNet residual-stage tensors into two independent streams; '
                'the supplied 3-convolution stems remain randomly initialized.',loaded)
    return loaded
