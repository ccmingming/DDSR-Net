import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.init import constant_, xavier_uniform_
from .utils import multi_scale_deformable_attn_pytorch

def sample_density_at_points(density_map, reference_points):
    pass

    sampling_grid = reference_points.unsqueeze(2) * 2.0 - 1.0
    density_values = F.grid_sample(
        density_map,
        sampling_grid,
        mode='bilinear',
        padding_mode='zeros',
        align_corners=False
    )

    return density_values.squeeze(-1).permute(0, 2, 1)

def sparsemax(logits, dim=-1):
    pass
    z = logits - logits.max(dim=dim, keepdim=True).values
    ordered = z.sort(dim=dim, descending=True).values
    cumulative = ordered.cumsum(dim)
    shape = [1] * z.ndim
    shape[dim] = z.shape[dim]
    rank = torch.arange(1, z.shape[dim] + 1, device=z.device, dtype=z.dtype).view(shape)
    support = 1 + rank * ordered > cumulative
    count = support.sum(dim=dim, keepdim=True).clamp_min(1)
    tau = (cumulative.gather(dim, count - 1) - 1) / count.to(z.dtype)
    return (z - tau).clamp_min(0)

class DensityRoutedMoE(nn.Module):
    def __init__(self, d_model, d_ffn, dropout=0.0, act=nn.ReLU()):
        super().__init__()

        self.expert_vis = nn.Sequential(nn.Linear(d_model, d_ffn), act, nn.Dropout(dropout), nn.Linear(d_ffn, d_model))

        self.expert_ther = nn.Sequential(nn.Linear(d_model, d_ffn), act, nn.Dropout(dropout), nn.Linear(d_ffn, d_model))

        self.expert_fuse = nn.Sequential(nn.Linear(d_model, d_ffn), act, nn.Dropout(dropout), nn.Linear(d_ffn, d_model))

        self.router = nn.Linear(d_model + 2, 3, bias=False)

    def forward(self, x, density_val, align_uncertainty):

        router_in = torch.cat([x, density_val, align_uncertainty], dim=-1)

        weights = sparsemax(self.router(router_in), dim=-1)

        out_vis = self.expert_vis(x)
        out_ther = self.expert_ther(x)
        out_fuse = self.expert_fuse(x)

        return (weights[..., 0:1] * out_vis +
                weights[..., 1:2] * out_ther +
                weights[..., 2:3] * out_fuse)

class MSDeformAttn(nn.Module):
    def __init__(self, d_model=256, n_levels=4, n_heads=8, n_points=4):
        super().__init__()
        if d_model % n_heads != 0:
            raise ValueError(f"d_model must be divisible by n_heads, but got {d_model} and {n_heads}")
        _d_per_head = d_model // n_heads
        assert _d_per_head * n_heads == d_model, "`d_model` must be divisible by `n_heads`"

        self.im2col_step = 64
        self.d_model = d_model
        self.n_levels = n_levels
        self.n_heads = n_heads
        self.n_points = n_points

        self.sampling_offsets = nn.Linear(d_model, n_heads * n_levels * n_points * 2)
        self.attention_weights = nn.Linear(d_model, n_heads * n_levels * n_points)
        self.value_proj = nn.Linear(d_model, d_model)
        self.output_proj = nn.Linear(d_model, d_model)
        self._reset_parameters()

    def _reset_parameters(self):
        constant_(self.sampling_offsets.weight.data, 0.0)
        thetas = torch.arange(self.n_heads, dtype=torch.float32) * (2.0 * math.pi / self.n_heads)
        grid_init = torch.stack([thetas.cos(), thetas.sin()], -1)
        grid_init = (
            (grid_init / grid_init.abs().max(-1, keepdim=True)[0])
                .view(self.n_heads, 1, 1, 2)
                .repeat(1, self.n_levels, self.n_points, 1)
        )
        for i in range(self.n_points):
            grid_init[:, :, i, :] *= i + 1
        with torch.no_grad():
            self.sampling_offsets.bias = nn.Parameter(grid_init.view(-1))
        constant_(self.attention_weights.weight.data, 0.0)
        constant_(self.attention_weights.bias.data, 0.0)
        xavier_uniform_(self.value_proj.weight.data)
        constant_(self.value_proj.bias.data, 0.0)
        xavier_uniform_(self.output_proj.weight.data)
        constant_(self.output_proj.bias.data, 0.0)

    def forward(self, query, refer_bbox, value, value_shapes, value_mask=None, need_weights=False):

        bs, len_q = query.shape[:2]
        len_v = value.shape[1]
        assert sum(s[0] * s[1] for s in value_shapes) == len_v

        value = self.value_proj(value)
        if value_mask is not None:
            value = value.masked_fill(value_mask[..., None], float(0))
        value = value.view(bs, len_v, self.n_heads, self.d_model // self.n_heads)
        sampling_offsets = self.sampling_offsets(query).view(bs, len_q, self.n_heads, self.n_levels, self.n_points, 2)
        attention_weights = self.attention_weights(query).view(bs, len_q, self.n_heads, self.n_levels * self.n_points)
        attention_weights = F.softmax(attention_weights, -1).view(bs, len_q, self.n_heads, self.n_levels, self.n_points)

        num_points = refer_bbox.shape[-1]
        if num_points == 2:
            offset_normalizer = torch.as_tensor(value_shapes, dtype=query.dtype, device=query.device).flip(-1)
            add = sampling_offsets / offset_normalizer[None, None, None, :, None, :]
            sampling_locations = refer_bbox[:, :, None, :, None, :] + add
        elif num_points == 4:
            add = sampling_offsets / self.n_points * refer_bbox[:, :, None, :, None, 2:] * 0.5
            sampling_locations = refer_bbox[:, :, None, :, None, :2] + add
        else:
            raise ValueError(f"Last dim of reference_points must be 2 or 4, but got {num_points}.")

        output = multi_scale_deformable_attn_pytorch(value, value_shapes, sampling_locations, attention_weights)
        output = self.output_proj(output)

        if need_weights:
            return output, sampling_locations
        return output

class DeformableTransformerDecoderLayer(nn.Module):
    def __init__(self, d_model=256, n_heads=8, d_ffn=1024, dropout=0.0, act=nn.ReLU(), n_levels=4, n_points=4):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(d_model, n_heads, dropout=dropout)
        self.dropout1 = nn.Dropout(dropout)
        self.norm1 = nn.LayerNorm(d_model)
        self.cross_attn = MSDeformAttn(d_model, n_levels, n_heads, n_points)
        self.dropout2 = nn.Dropout(dropout)
        self.norm2 = nn.LayerNorm(d_model)
        self.linear1 = nn.Linear(d_model, d_ffn)
        self.act = act
        self.dropout3 = nn.Dropout(dropout)
        self.linear2 = nn.Linear(d_ffn, d_model)
        self.dropout4 = nn.Dropout(dropout)
        self.norm3 = nn.LayerNorm(d_model)

    @staticmethod
    def with_pos_embed(tensor, pos):
        return tensor if pos is None else tensor + pos

    def forward_ffn(self, tgt):
        tgt2 = self.linear2(self.dropout3(self.act(self.linear1(tgt))))
        tgt = tgt + self.dropout4(tgt2)
        return self.norm3(tgt)

    def forward(self, embed, refer_bbox, feats, shapes, padding_mask=None, attn_mask=None, query_pos=None):
        q = k = self.with_pos_embed(embed, query_pos)
        tgt = self.self_attn(q.transpose(0, 1), k.transpose(0, 1), embed.transpose(0, 1), attn_mask=attn_mask)[
            0].transpose(0, 1)
        embed = embed + self.dropout1(tgt)
        embed = self.norm1(embed)
        tgt = self.cross_attn(self.with_pos_embed(embed, query_pos), refer_bbox.unsqueeze(2), feats, shapes,
                              padding_mask)
        embed = embed + self.dropout2(tgt)
        embed = self.norm2(embed)
        return self.forward_ffn(embed)

class DensityGuidedDecoderLayer(DeformableTransformerDecoderLayer):
    pass

    def __init__(self, d_model=256, n_heads=8, d_ffn=1024, dropout=0.0,
                 act=nn.ReLU(), n_levels=4, n_points=4):
        super().__init__(d_model, n_heads, d_ffn, dropout, act, n_levels, n_points)
        self.density_gate = nn.Sequential(nn.Linear(1, d_model), nn.Sigmoid())
        self.moe_block = DensityRoutedMoE(d_model, d_ffn, dropout, act)

        del self.linear1, self.linear2, self.norm3

    def forward(self, embed, refer_bbox, feats, shapes, padding_mask=None,
                attn_mask=None, query_pos=None, density_map=None, alignment_map=None,
                query_padding_mask=None):
        q = k = self.with_pos_embed(embed, query_pos)
        attended = self.self_attn(q.transpose(0, 1), k.transpose(0, 1), embed.transpose(0, 1),
                                  attn_mask=attn_mask, key_padding_mask=query_padding_mask,
                                  need_weights=False)[0].transpose(0, 1)
        state = self.norm1(embed + self.dropout1(attended))
        b, nq = state.shape[:2]
        rho = state.new_zeros(b, nq, 1)
        eta = state.new_zeros(b, nq, 1)
        points = refer_bbox[..., :2]
        if density_map is not None:

            rho = sample_density_at_points(density_map.detach(), points)
        if alignment_map is not None:
            eta = sample_density_at_points(alignment_map, points)

        modulated_query = state * self.density_gate(rho)
        cross = self.cross_attn(modulated_query, refer_bbox.unsqueeze(2), feats, shapes, padding_mask)
        state = self.norm2(state + self.dropout2(cross))
        routed = self.moe_block(state, rho, eta)
        if query_padding_mask is not None:
            routed = routed.masked_fill(query_padding_mask[..., None], 0)
        return routed

class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_layers, act=nn.ReLU, sigmoid=False):
        super().__init__();
        self.num_layers = num_layers;
        h = [hidden_dim] * (num_layers - 1);
        self.layers = nn.ModuleList(nn.Linear(n, k) for n, k in zip([input_dim] + h, h + [output_dim]));
        self.sigmoid = sigmoid;
        self.act = act()

    def forward(self, x):
        for i, layer in enumerate(self.layers): x = getattr(self, "act", nn.ReLU())(
            layer(x)) if i < self.num_layers - 1 else layer(x)
        return x.sigmoid() if getattr(self, "sigmoid", False) else x
