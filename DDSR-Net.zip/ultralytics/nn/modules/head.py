import copy
import torch
import torch.nn as nn
from torch.nn.init import constant_
from .density import DensityQueryInitializer
from .transformer import MLP, DensityGuidedDecoderLayer
from .utils import bias_init_with_prob, inverse_sigmoid

class DeFE(DensityQueryInitializer):
    pass
    def __init__(self, in_channels=64, nmax=100, quantile=0.8, pool=4,
                 z_min=0.001, dbscan_eps=1.5, min_samples=3):
        super().__init__(in_channels, nmax, quantile, pool, z_min, dbscan_eps, min_samples)
        self.proc_channels = in_channels

    def forward(self, x, image_size=None):
        if image_size is None:
            raise ValueError('DeFE requires the actual input image size from RTDETRDetectionModel.predict')
        if x.shape[1] != self.proc_channels + 1:
            raise ValueError('DeFE expects [F_fused, U_deg] with C+1 channels')
        return super().forward({'query_feature': x[:, :-1], 'uncertainty': x[:, -1:],
                                'image_size': image_size})

class RTDETRDecoder(nn.Module):
    pass

    export = False

    def __init__(self, nc=80, ch=(256, 256, 256, 256, 64), hd=256, nq=100,
                 ndp=4, nh=8, ndl=3, d_ffn=1024, dropout=0.0, act=nn.ReLU(), **kwargs):
        super().__init__()
        self.nc, self.hidden_dim, self.num_queries = nc, hd, nq
        self.nl, self.num_decoder_layers = len(ch) - 1, ndl

        self.input_proj = nn.ModuleList(
            nn.Identity() if c == hd else
            nn.Sequential(nn.Conv2d(c, hd, 1, bias=False), nn.BatchNorm2d(hd))
            for c in ch[:-1])
        self.content_proj = nn.Linear(ch[-1], hd)
        self.query_pos_head = MLP(2, 2 * hd, hd, num_layers=2)
        self.layers = nn.ModuleList(DensityGuidedDecoderLayer(hd, nh, d_ffn, dropout, copy.deepcopy(act), self.nl, ndp)
                                    for _ in range(ndl))
        self.score_head = nn.Linear(hd, nc)
        self.bbox_head = MLP(hd, hd, 4, num_layers=3)
        constant_(self.score_head.bias, bias_init_with_prob(0.01))
        constant_(self.bbox_head.layers[-1].weight, 0)
        constant_(self.bbox_head.layers[-1].bias, 0)

    def forward(self, x, batch=None):
        query = x[-1]
        if not isinstance(query, dict) or 'anchors' not in query:
            raise ValueError('RTDETRDecoder must receive the DeFE query dictionary as its last YAML input')
        anchors, active = query['anchors'], query['active_mask']
        if anchors.shape[1] != self.num_queries:
            raise ValueError('DQI and decoder Nmax must match')
        feats, shapes = [], []
        for feature, projection in zip(x[:-1], self.input_proj):
            feature = projection(feature)
            shapes.append(feature.shape[-2:])
            feats.append(feature.flatten(2).transpose(1, 2))
        memory = torch.cat(feats, dim=1)
        content = self.content_proj(query['content']).masked_fill(~active[..., None], 0)
        position = self.query_pos_head(anchors).masked_fill(~active[..., None], 0)
        for layer in self.layers:
            content = layer(content, anchors, memory, shapes, query_pos=position,
                            density_map=query['density'], alignment_map=query['uncertainty'],
                            query_padding_mask=~active)

        reference = torch.cat((anchors, torch.full_like(anchors, 0.05)), -1)
        boxes = (self.bbox_head(content) + inverse_sigmoid(reference)).sigmoid()
        scores = self.score_head(content)
        metadata = {'density': query['density'], 'active_mask': active,
                    'counts': query['counts'], 'anchors': anchors,
                    'query_diagnostics': query.get('query_diagnostics', [])}
        output = (boxes.unsqueeze(0), scores.unsqueeze(0), None, None, metadata)
        if self.training:
            return output
        confidence = scores.sigmoid().masked_fill(~active[..., None], 0)
        prediction = torch.cat((boxes, confidence), dim=-1)
        return prediction if self.export else (prediction, output)
