import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.cluster import DBSCAN

class DensityQueryInitializer(nn.Module):

    def __init__(self, channels=256, nmax=100, quantile=0.8, pool=4, z_min=0.001, dbscan_eps=1.5, min_samples=3, query_mode='paper', min_queries=1, warmup_steps=0):
        super().__init__()
        if nmax < 1 or not 0 <= quantile <= 1 or pool < 1 or (min_samples < 1):
            raise ValueError('Invalid DQI configuration')
        self.nmax, self.quantile, self.pool = (nmax, quantile, pool)
        self.z_min, self.dbscan_eps, self.min_samples = (z_min, dbscan_eps, min_samples)
        self.configure_queries(query_mode, min_queries, warmup_steps)
        layers = []
        for dilation in (1, 3, 5):
            layers += [nn.Conv2d(channels, channels, 3, padding=dilation, dilation=dilation, groups=channels), nn.ReLU(inplace=True)]
        self.dilated_convs = nn.Sequential(*layers)
        self.channel_attn = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(channels, max(1, channels // 4), 1), nn.ReLU(inplace=True), nn.Conv2d(max(1, channels // 4), channels, 1), nn.Sigmoid())
        self.density_head = nn.Conv2d(channels, 1, 3, padding=1)

    def configure_queries(self, mode='paper', min_queries=1, warmup_steps=0):
        if mode != 'paper' or min_queries != 1 or warmup_steps != 0:
            raise ValueError('DQI only supports the paper query mode')
        self.query_mode, self.min_queries = (mode, int(min_queries))
        self.last_query_stats = None

    @torch.no_grad()
    def select_anchors(self, density):
        pass
        if torch.jit.is_tracing() or torch.onnx.is_in_onnx_export():
            raise NotImplementedError('Dynamic DBSCAN must be implemented by the export backend; tracing would freeze anchors')
        if not torch.isfinite(density).all():
            raise FloatingPointError('DQI received non-finite density')
        b, _, h, w = density.shape
        k = min(self.pool, h, w)
        z = F.avg_pool2d(density.detach(), k, k, ceil_mode=True, count_include_pad=False)
        z_np, full = (z[:, 0].float().cpu().numpy(), density[:, 0].detach().float().cpu().numpy())
        peak_candidates = None
        anchors = density.new_full((b, self.nmax, 2), 0.5)
        active = torch.zeros(b, self.nmax, device=density.device, dtype=torch.bool)
        counts, diagnostics = ([], [])
        for image in range(b):
            coords = np.argwhere(z_np[image] > self.z_min)
            clusters = []
            if len(coords):
                labels = DBSCAN(eps=self.dbscan_eps, min_samples=self.min_samples, algorithm='kd_tree').fit_predict(coords)
                for label in np.unique(labels):
                    if label < 0:
                        continue
                    pixels = coords[labels == label]
                    mean = float(z_np[image, pixels[:, 0], pixels[:, 1]].mean())
                    clusters.append((mean, pixels))
            peaks, kept = ([], [])
            retained = 0
            if clusters:
                threshold = float(np.quantile([c[0] for c in clusters], self.quantile))
                retained_clusters = sorted((c for c in clusters if c[0] >= threshold), key=lambda c: -c[0])
                retained = len(retained_clusters)
                kept = retained_clusters[:self.nmax]
                for mean, pixels in kept:
                    mask = np.zeros(z_np[image].shape, dtype=bool)
                    mask[pixels[:, 0], pixels[:, 1]] = True
                    mask = mask.repeat(k, 0).repeat(k, 1)[:h, :w]
                    peak = int(np.argmax(np.where(mask, full[image], -np.inf)))
                    y, x = divmod(peak, w)
                    peaks.append((y, x))
            fallback = not peaks
            if fallback:
                y, x = divmod(int(full[image].argmax()), w)
                peaks = [(y, x)]
            added_peaks = added_grid = 0
            count = len(peaks)
            anchors[image, :count] = density.new_tensor([((x + 0.5) / w, (y + 0.5) / h) for y, x in peaks])
            active[image, :count] = True
            counts.append(count)
            diagnostics.append({'clusters': len(clusters), 'retained': retained, 'cluster_anchors': len(kept), 'fallback': fallback, 'added_peaks': added_peaks, 'added_grid': added_grid, 'active': count})
        self.last_query_stats = diagnostics
        return (anchors, active, torch.tensor(counts, dtype=torch.long, device=density.device))

    def forward(self, context):
        fused = context['query_feature']
        feature = self.dilated_convs(fused)
        logits = self.density_head(feature * self.channel_attn(feature))
        density = F.interpolate(logits, size=context['image_size'], mode='bilinear', align_corners=False).sigmoid()
        anchors, active, counts = self.select_anchors(density)
        grid = anchors[:, :, None, :] * 2 - 1
        content = F.grid_sample(fused, grid, align_corners=False, padding_mode='border').squeeze(-1).transpose(1, 2)
        content = content.masked_fill(~active[..., None], 0)
        return dict(context, density=density, anchors=anchors, active_mask=active, counts=counts, content=content, query_diagnostics=self.last_query_stats)

def build_density_target(boxes, batch_idx, batch_size, size, sigma=5.0, normalization='mass'):
    pass
    if normalization not in ('mass', 'peak', 'peak_max') or sigma <= 0:
        raise ValueError('Invalid Gaussian target settings')
    h, w = size
    target = boxes.new_zeros(batch_size, 1, h, w, dtype=torch.float32)
    r = int(np.ceil(3 * sigma))
    for box, image in zip(boxes.detach(), batch_idx.detach()):
        cx, cy = (float(box[0]) * w - 0.5, float(box[1]) * h - 0.5)
        x0, x1 = (max(0, int(np.floor(cx)) - r), min(w, int(np.floor(cx)) + r + 2))
        y0, y1 = (max(0, int(np.floor(cy)) - r), min(h, int(np.floor(cy)) + r + 2))
        if x1 <= x0 or y1 <= y0:
            continue
        yy = torch.arange(y0, y1, device=boxes.device, dtype=torch.float32)[:, None]
        xx = torch.arange(x0, x1, device=boxes.device, dtype=torch.float32)[None, :]
        kernel = torch.exp(-((xx - cx).square() + (yy - cy).square()) / (2 * sigma ** 2))
        denom = kernel.sum() if normalization == 'mass' else kernel.max()
        kernel = kernel / denom.clamp_min(1e-12)
        if normalization == 'peak_max':
            region = target[int(image), 0, y0:y1, x0:x1]
            region.copy_(torch.maximum(region, kernel))
        else:
            target[int(image), 0, y0:y1, x0:x1] += kernel
    return target

def density_loss(prediction, target, eps=1e-08, l1_reduction='sum', foreground_threshold=0.1):
    pass
    p, t = (prediction.float().flatten(1), target.float().flatten(1))
    error = (p - t).abs()
    if l1_reduction == 'sum':
        l1 = error.sum(1)
    elif l1_reduction == 'balanced':
        if not 0 < foreground_threshold <= 1:
            raise ValueError('foreground_threshold must be in (0,1]')
        foreground = t >= foreground_threshold
        n_fg, n_bg = (foreground.sum(1), (~foreground).sum(1))
        fg = (error * foreground).sum(1) / n_fg.clamp_min(1)
        bg = (error * ~foreground).sum(1) / n_bg.clamp_min(1)
        l1 = torch.where((n_fg > 0) & (n_bg > 0), 0.5 * (fg + bg), fg + bg)
    else:
        raise ValueError('density l1_reduction must be sum or balanced')
    dice = 1 - 2 * (p * t).sum(1) / (p.sum(1) + t.sum(1) + eps)
    return (l1 + dice).mean()
