import math
import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ('DualScaleHessian', 'LocalMatching', 'FaultDiagnosticAlignment', 'SpatialDualAttention')

class DualScaleHessian(nn.Module):
    pass

    def __init__(self, sigmas=(1.5, 4.0), beta=0.5, eps=1e-8):
        super().__init__()
        if len(sigmas) != 2 or min(sigmas) <= 0 or beta <= 0:
            raise ValueError('FDA requires two positive scales and beta > 0')
        self.sigmas, self.beta, self.eps = tuple(sigmas), beta, eps
        for i, sigma in enumerate(sigmas):
            r = math.ceil(3 * sigma)
            coord = torch.arange(-r, r + 1, dtype=torch.float64)
            yy, xx = torch.meshgrid(coord, coord, indexing='ij')
            g = torch.exp(-(xx.square() + yy.square()) / (2 * sigma**2))
            g /= g.sum()
            kernels = torch.stack([(xx.square() / sigma**4 - 1 / sigma**2) * g,
                                   xx * yy / sigma**4 * g,
                                   (yy.square() / sigma**4 - 1 / sigma**2) * g])
            kernels -= kernels.mean(dim=(-1, -2), keepdim=True)
            self.register_buffer('kernel_%d' % i, (sigma**2 * kernels[:, None]).float())

    def hessian(self, image, index):
        kernel = getattr(self, 'kernel_%d' % index).to(image)
        pad = kernel.shape[-1] // 2
        return F.conv2d(F.pad(image, (pad,) * 4, mode='replicate'), kernel)

    def single_scale(self, image, index):
        hxx, hxy, hyy = self.hessian(image, index).chunk(3, dim=1)
        root = ((hxx - hyy).square() + 4 * hxy.square()).clamp_min(1e-20).sqrt()
        a = ((hxx + hyy + root) * 0.5).abs()
        b = ((hxx + hyy - root) * 0.5).abs()
        k1, k2 = torch.maximum(a, b), torch.minimum(a, b)
        iso = k2 / (k1 + self.eps)
        return (k1 - k2) * torch.exp(-iso.square() / (2 * self.beta**2))

    def forward(self, image):
        if image.ndim != 4 or image.shape[1] != 1:
            raise ValueError('Hessian guide must be [B, 1, H, W]')
        return torch.maximum(self.single_scale(image, 0), self.single_scale(image, 1))

class LocalMatching(nn.Module):
    pass
    def __init__(self, channels=None, patch_size=3, search_radius=4, eps=1e-8):
        super().__init__()
        if patch_size < 1 or patch_size % 2 == 0 or search_radius < 0:
            raise ValueError('Use an odd positive patch size and nonnegative radius')
        self.patch_size, self.radius, self.eps = patch_size, search_radius, eps

    def forward(self, query_guide, search_guide, value_source, return_details=False):
        b, _, h, w = query_guide.shape
        if search_guide.shape != query_guide.shape or value_source.shape[-2:] != (h, w):
            raise ValueError('FDA guides and values must share the spatial lattice')
        p = self.patch_size
        query = F.unfold(F.pad(query_guide, (p // 2,) * 4, mode='replicate'), p).reshape(b, -1, h, w)
        search = F.unfold(F.pad(search_guide, (p // 2,) * 4, mode='replicate'), p).reshape(b, -1, h, w)
        r = self.radius
        padded = F.pad(search, (r,) * 4)
        yy, xx = torch.meshgrid(torch.arange(h, device=query.device), torch.arange(w, device=query.device), indexing='ij')

        offsets = sorted(((dy, dx) for dy in range(-r, r + 1) for dx in range(-r, r + 1)),
                         key=lambda t: (t[0]**2 + t[1]**2, t[0], t[1]))
        scores = []
        qnorm = query.square().sum(1).clamp_min(1e-20).sqrt()
        for dy, dx in offsets:
            candidate = padded[:, :, r + dy:r + dy + h, r + dx:r + dx + w]
            cnorm = candidate.square().sum(1).clamp_min(1e-20).sqrt()
            sim = (query * candidate).sum(1) / (qnorm * cnorm + self.eps)
            valid = (yy + dy >= 0) & (yy + dy < h) & (xx + dx >= 0) & (xx + dx < w)
            scores.append(sim.masked_fill(~valid, -torch.inf))
        peak, index = torch.stack(scores, dim=1).max(1)
        offset_yx = query.new_tensor(offsets)[index]
        grid = torch.stack([2 * (xx + offset_yx[..., 1] + 0.5) / w - 1,
                            2 * (yy + offset_yx[..., 0] + 0.5) / h - 1], dim=-1)
        aligned = F.grid_sample(value_source, grid, mode='bilinear', padding_mode='border', align_corners=False)
        peak = peak[:, None]
        lo = peak.flatten(2).min(-1).values[..., None, None]
        hi = peak.flatten(2).max(-1).values[..., None, None]
        uncertainty = (hi - peak) / (hi - lo + self.eps)
        if return_details:
            return aligned, uncertainty, offset_yx.flip(-1), peak
        return aligned, uncertainty

class FaultDiagnosticAlignment(nn.Module):
    pass

    def __init__(self, channels, sigmas=(1.5, 4.0), beta=0.5, patch_size=3,
                 search_radius=4, direction='ir_reference'):
        super().__init__()
        if direction not in ('paper_literal', 'ir_reference'):
            raise ValueError('Unknown FDA coordinate convention')
        self.direction = direction
        self.structure_reduce = nn.Conv2d(channels, 1, 1, bias=False)
        nn.init.constant_(self.structure_reduce.weight, 1.0 / channels)
        self.aligner = DualScaleHessian(sigmas, beta)
        self.matcher = LocalMatching(patch_size=patch_size, search_radius=search_radius)

    def forward(self, pair):
        vis, ir = pair
        if vis.shape != ir.shape:
            raise ValueError('FDA requires equal feature dimensions from both streams')
        vis_guide = self.aligner(self.structure_reduce(vis))
        ir_guide = self.aligner(self.structure_reduce(ir))
        query, search = (vis_guide, ir_guide) if self.direction == 'paper_literal' else (ir_guide, vis_guide)
        aligned, uncertainty = self.matcher(query, search, vis)
        fused = aligned + ir
        return {'fused': fused, 'uncertainty': uncertainty,
                'augmented': torch.cat([fused, uncertainty], dim=1)}

class SpatialDualAttention(FaultDiagnosticAlignment):
    pass
    def forward(self, pair):
        return super().forward(pair)['augmented']
