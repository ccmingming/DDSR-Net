import contextlib
import glob
import os
import shutil
import tempfile
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

class WorkingDirectory(contextlib.ContextDecorator):
    pass

    def __init__(self, new_dir):
        pass
        self.dir = new_dir
        self.cwd = Path.cwd().resolve()

    def __enter__(self):
        pass
        os.chdir(self.dir)

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass
        os.chdir(self.cwd)

@contextmanager
def spaces_in_path(path):
    pass

    if " " in str(path):
        string = isinstance(path, str)
        path = Path(path)

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir) / path.name.replace(" ", "_")

            if path.is_dir():

                shutil.copytree(path, tmp_path)
            elif path.is_file():
                tmp_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, tmp_path)

            try:

                yield str(tmp_path) if string else tmp_path

            finally:

                if tmp_path.is_dir():
                    shutil.copytree(tmp_path, path, dirs_exist_ok=True)
                elif tmp_path.is_file():
                    shutil.copy2(tmp_path, path)

    else:

        yield path

def increment_path(path, exist_ok=False, sep="", mkdir=False):
    pass

    path = Path(path)
    if path.exists() and not exist_ok:
        path, suffix = (path.with_suffix(""), path.suffix) if path.is_file() else (path, "")

        for n in range(2, 9999):
            p = f"{path}{sep}{n}{suffix}"
            if not os.path.exists(p):
                break
        path = Path(p)

    if mkdir:
        path.mkdir(parents=True, exist_ok=True)

    return path

def file_age(path=__file__):
    pass
    dt = datetime.now() - datetime.fromtimestamp(Path(path).stat().st_mtime)
    return dt.days

def file_date(path=__file__):
    pass
    t = datetime.fromtimestamp(Path(path).stat().st_mtime)
    return f"{t.year}-{t.month}-{t.day}"

def file_size(path):
    pass
    if isinstance(path, (str, Path)):
        mb = 1 << 20
        path = Path(path)
        if path.is_file():
            return path.stat().st_size / mb
        elif path.is_dir():
            return sum(f.stat().st_size for f in path.glob("**/*") if f.is_file()) / mb
    return 0.0

def get_latest_run(search_dir="."):
    pass
    last_list = glob.glob(f"{search_dir}/**/last*.pt", recursive=True)
    return max(last_list, key=os.path.getctime) if last_list else ""

