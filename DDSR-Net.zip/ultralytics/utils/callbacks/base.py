from collections import defaultdict
from copy import deepcopy

def on_pretrain_routine_start(trainer):
    pass
    pass

def on_pretrain_routine_end(trainer):
    pass
    pass

def on_train_start(trainer):
    pass
    pass

def on_train_epoch_start(trainer):
    pass
    pass

def on_train_batch_start(trainer):
    pass
    pass

def optimizer_step(trainer):
    pass
    pass

def on_before_zero_grad(trainer):
    pass
    pass

def on_train_batch_end(trainer):
    pass
    pass

def on_train_epoch_end(trainer):
    pass
    pass

def on_fit_epoch_end(trainer):
    pass
    pass

def on_model_save(trainer):
    pass
    pass

def on_train_end(trainer):
    pass
    pass

def on_params_update(trainer):
    pass
    pass

def teardown(trainer):
    pass
    pass

def on_val_start(validator):
    pass
    pass

def on_val_batch_start(validator):
    pass
    pass

def on_val_batch_end(validator):
    pass
    pass

def on_val_end(validator):
    pass
    pass

def on_predict_start(predictor):
    pass
    pass

def on_predict_batch_start(predictor):
    pass
    pass

def on_predict_batch_end(predictor):
    pass
    pass

def on_predict_postprocess_end(predictor):
    pass
    pass

def on_predict_end(predictor):
    pass
    pass

def on_export_start(exporter):
    pass
    pass

def on_export_end(exporter):
    pass
    pass

default_callbacks = {

    "on_pretrain_routine_start": [on_pretrain_routine_start],
    "on_pretrain_routine_end": [on_pretrain_routine_end],
    "on_train_start": [on_train_start],
    "on_train_epoch_start": [on_train_epoch_start],
    "on_train_batch_start": [on_train_batch_start],
    "optimizer_step": [optimizer_step],
    "on_before_zero_grad": [on_before_zero_grad],
    "on_train_batch_end": [on_train_batch_end],
    "on_train_epoch_end": [on_train_epoch_end],
    "on_fit_epoch_end": [on_fit_epoch_end],
    "on_model_save": [on_model_save],
    "on_train_end": [on_train_end],
    "on_params_update": [on_params_update],
    "teardown": [teardown],

    "on_val_start": [on_val_start],
    "on_val_batch_start": [on_val_batch_start],
    "on_val_batch_end": [on_val_batch_end],
    "on_val_end": [on_val_end],

    "on_predict_start": [on_predict_start],
    "on_predict_batch_start": [on_predict_batch_start],
    "on_predict_postprocess_end": [on_predict_postprocess_end],
    "on_predict_batch_end": [on_predict_batch_end],
    "on_predict_end": [on_predict_end],

    "on_export_start": [on_export_start],
    "on_export_end": [on_export_end],
}

def get_default_callbacks():
    pass

    return defaultdict(list, deepcopy(default_callbacks))

def add_integration_callbacks(instance):
    if "Trainer" in instance.__class__.__name__:
        from .tensorboard import callbacks
        for event, func in callbacks.items():
            if func not in instance.callbacks[event]:
                instance.callbacks[event].append(func)
