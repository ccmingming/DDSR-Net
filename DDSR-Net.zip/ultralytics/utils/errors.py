from ultralytics.utils import emojis

class HUBModelError(Exception):
    pass

    def __init__(self, message="Model not found. Please check model URL and try again."):
        pass
        super().__init__(emojis(message))
