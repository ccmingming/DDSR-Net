import warnings
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment
from ultralytics.utils.metrics import bbox_iou
from ultralytics.utils import LOGGER
from ultralytics.nn.modules.density import build_density_target, density_loss

class DDSRLoss(nn.Module):
    def __init__(self, nc, sigma=5.0, normalization='mass', shortage='warn', match_class_weight=1.0,
                 density_l1='sum', diagnostics_interval=0, foreground_threshold=.1):
        super().__init__()
        if shortage not in ('warn', 'error'):
            raise ValueError('shortage must be warn or error')
        self.nc, self.sigma, self.normalization = nc, sigma, normalization
        self.shortage, self.match_class_weight = shortage, match_class_weight
        self._shortage_reported = False
        self.density_l1, self.diagnostics_interval = density_l1, int(diagnostics_interval)
        self.calls = 0
        self.foreground_threshold = foreground_threshold

    def forward(self, output, targets):
        boxes, logits, _, _, meta = output
        boxes, logits = boxes[-1], logits[-1]
        b = boxes.shape[0]

        cls = targets['cls'].detach().cpu().reshape(-1)
        indices = targets['batch_idx'].detach().cpu().reshape(-1)
        if logits.shape[-1] != self.nc:
            raise ValueError('DDSR prediction class dimension does not match nc')
        if not (torch.isfinite(cls).all() and (cls == cls.trunc()).all() and (cls >= 0).all() and (cls < self.nc).all()):
            raise ValueError('DDSR requires integer class IDs in [0,%d]; got %s; images=%s' %
                             (self.nc - 1, cls.tolist(), targets.get('im_file', ())))
        if not (torch.isfinite(indices).all() and (indices == indices.trunc()).all() and (indices >= 0).all() and (indices < b).all()):
            raise ValueError('DDSR invalid batch_idx')
        target_boxes = targets['bboxes'].to(device=boxes.device, dtype=boxes.dtype)
        if target_boxes.ndim != 2 or target_boxes.shape[1] != 4 or len(target_boxes) != len(cls) or len(indices) != len(cls):
            raise ValueError('DDSR requires matching cls/batch_idx/bboxes lengths and xywh [N,4]')
        if not torch.isfinite(target_boxes).all():
            raise ValueError('DDSR ground-truth boxes contain NaN/Inf')
        targets = {'cls': cls.to(device=boxes.device, dtype=torch.long), 'bboxes': target_boxes,
                   'batch_idx': indices.to(device=boxes.device, dtype=torch.long)}
        zero = logits.sum() * 0
        components = dict(loss_class=zero, loss_bbox=zero, loss_giou=zero)
        unmatched = 0
        for i in range(b):
            active = meta['active_mask'][i]
            pred_boxes, pred_logits = boxes[i, active], logits[i, active]
            selected = targets['batch_idx'] == i
            gt_boxes, gt_cls = targets['bboxes'][selected], targets['cls'][selected]
            labels = torch.zeros_like(pred_logits)
            if len(gt_boxes):
                unmatched += max(0, len(gt_boxes) - len(pred_boxes))
                if len(gt_boxes) > len(pred_boxes) and self.shortage == 'error':
                    raise ValueError('Query deficit: DQI N_act < M. Rectangular matching is defined in paper Section 4.5.')
                with torch.no_grad():
                    probability = pred_logits.sigmoid()[:, gt_cls]
                    cost_l1 = torch.cdist(pred_boxes, gt_boxes, p=1)
                    cost_giou = 1 - bbox_iou(pred_boxes[:, None], gt_boxes[None], xywh=True, GIoU=True).squeeze(-1)
                    cost = -self.match_class_weight * probability + 5.0 * cost_l1 + 2.0 * cost_giou
                    if not torch.isfinite(cost).all():
                        raise FloatingPointError('Non-finite Hungarian cost; do not silently replace it with zero')
                    pi, gi = linear_sum_assignment(cost.cpu().numpy())
                    pi = torch.as_tensor(pi, device=boxes.device)
                    gi = torch.as_tensor(gi, device=boxes.device)
                labels[pi, gt_cls[gi]] = 1
                components['loss_bbox'] = components['loss_bbox'] + 5.0 * F.l1_loss(pred_boxes[pi], gt_boxes[gi], reduction='sum')
                giou = bbox_iou(pred_boxes[pi], gt_boxes[gi], xywh=True, GIoU=True)
                components['loss_giou'] = components['loss_giou'] + 2.0 * (1 - giou).sum()

            probability = pred_logits.sigmoid()
            pt = labels * probability + (1 - labels) * (1 - probability)
            alpha = labels * 0.25 + (1 - labels) * 0.75
            focal = alpha * (1 - pt).square() * F.binary_cross_entropy_with_logits(pred_logits, labels, reduction='none')
            components['loss_class'] = components['loss_class'] + 2.0 * focal.sum()
        if unmatched and not self._shortage_reported:
            LOGGER.warning('DDSR: %d GTs unmatched because N_act < M; Eq.(21) matches min(M, N_act) pairs.', unmatched)
            warnings.warn('DQI N_act is smaller than the number of GT objects. Rectangular Hungarian matching '
                          'leaves %d GTs unmatched in this batch; density still supervises every GT. '
                          'Eq.(21) uses rectangular matching in this case.' % unmatched,
                          RuntimeWarning)
            self._shortage_reported = True
        self.last_unmatched_gt = unmatched
        components = {name: loss / b for name, loss in components.items()}
        target = build_density_target(targets['bboxes'], targets['batch_idx'], b,
                                      meta['density'].shape[-2:], self.sigma, self.normalization)
        components['loss_density'] = density_loss(meta['density'], target, l1_reduction=self.density_l1,
                                                foreground_threshold=self.foreground_threshold)
        self.calls += 1
        counts = meta['active_mask'].sum(1).detach().cpu()
        gt_counts = torch.bincount(indices.long(), minlength=b)
        total_gt = int(gt_counts.sum())
        self.last_stats = {'queries': counts.tolist(), 'gt': gt_counts.tolist(),
                           'matched_fraction': float(torch.minimum(counts,gt_counts).sum())/total_gt if total_gt else 1.,
                           'unmatched': unmatched, 'density_loss': float(components['loss_density'].detach()),
                           'density_max': float(meta['density'].detach().max()),
                           'density_mean': float(meta['density'].detach().mean()),
                           'target_mean': float(target.mean()),
                           'target_max': float(target.max()),
                           'query_diagnostics': meta.get('query_diagnostics', [])}
        if self.diagnostics_interval > 0 and (self.calls-1) % self.diagnostics_interval == 0:
            LOGGER.info('DDSR queries=%s GT=%s matchable=%.1f%% density_loss=%.4g '
                        'density_max=%.4g density_mean=%.4g target_max=%.4g target_mean=%.4g',
                        self.last_stats['queries'],self.last_stats['gt'],self.last_stats['matched_fraction']*100,
                        self.last_stats['density_loss'],self.last_stats['density_max'],self.last_stats['density_mean'],
                        self.last_stats['target_max'],self.last_stats['target_mean'])
            diagnostics = self.last_stats['query_diagnostics']
            if diagnostics:
                LOGGER.info('DDSR topology clusters=%s retained=%s fallback=%s added_peaks=%s added_grid=%s',
                            [d['clusters'] for d in diagnostics], [d['retained'] for d in diagnostics],
                            [d['fallback'] for d in diagnostics], [d['added_peaks'] for d in diagnostics],
                            [d['added_grid'] for d in diagnostics])
            if unmatched:
                LOGGER.warning('DDSR query deficit in this batch: %d GTs unmatched. '
                               'Check topology above; query_capacity alone does not set the active budget.', unmatched)
        return components
