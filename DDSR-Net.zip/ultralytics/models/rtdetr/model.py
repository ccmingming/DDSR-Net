from ultralytics.engine.model import Model
from ultralytics.nn.tasks import RTDETRDetectionModel

from .predict import RTDETRPredictor
from .train import RTDETRTrainer
from .val import RTDETRValidator

class RTDETR(Model):
    pass

    def __init__(self, model="rtdetr-l.pt") -> None:
        pass

        super().__init__(model=model, task="detect")

    @property
    def task_map(self) -> dict:
        pass

        return {
            "detect": {
                "predictor": RTDETRPredictor,
                "validator": RTDETRValidator,
                "trainer": RTDETRTrainer,
                "model": RTDETRDetectionModel,
            }
        }
