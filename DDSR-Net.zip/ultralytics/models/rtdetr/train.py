from copy import copy

import torch

from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.nn.tasks import RTDETRDetectionModel
from ultralytics.utils import DEFAULT_CFG, LOGGER, RANK, colorstr, yaml_load
from pathlib import Path
from ultralytics.utils.torch_utils import de_parallel

from .val import RTDETRDataset, RTDETRValidator

class RTDETRTrainer(DetectionTrainer):
    pass

    def __init__(self, cfg=DEFAULT_CFG, overrides=None, _callbacks=None):
        options = dict(overrides or {})
        path = options.get('model')
        if isinstance(path,(str,Path)) and Path(path).suffix in ('.yaml','.yml') and Path(path).is_file():
            settings = yaml_load(path)
            if settings.get('ddsr',False) and settings.get('ddsr_train'):
                profile = settings['ddsr_train']
                allowed = {'optimizer','lr0','lrf','cos_lr','weight_decay','warmup_epochs','nbs','patience',
                           'mosaic','mixup','copy_paste','hsv_h','hsv_s','hsv_v','degrees','translate','scale',
                           'shear','perspective','flipud','fliplr','bgr','plots','close_mosaic'}
                if set(profile)-allowed:
                    raise ValueError('Unsupported DDSR training profile keys: %s' % (set(profile)-allowed))
                LOGGER.info('DDSR p2.yaml training profile overrides entry settings: %s',profile)
                options.update(profile)
        super().__init__(cfg=cfg,overrides=options,_callbacks=_callbacks)

    def get_model(self, cfg=None, weights=None, verbose=True):
        pass

        model = RTDETRDetectionModel(cfg, nc=self.data["nc"], verbose=verbose and RANK == -1)
        if weights:
            model.load(weights)
        elif self.args.pretrained and model.yaml.get('imagenet_stages',False):
            from ultralytics.nn.modules.ddsr_training import load_imagenet_stages
            load_imagenet_stages(model,model.yaml.get('imagenet_weights'))
        return model

    def build_dataset(self, img_path, mode="val", batch=None):
        pass

        dataset = RTDETRDataset(
            img_path=img_path,
            imgsz=self.args.imgsz,
            batch_size=batch,
            augment=mode == "train",
            hyp=self.args,
            rect=False,
            cache=self.args.cache or None,
            prefix=colorstr(f"{mode}: "),
            data=self.data,
            ddsr_augmentation=bool(getattr(de_parallel(self.model),'yaml',{}).get('ddsr',False)),
        )
        model = de_parallel(self.model)
        if getattr(model,'yaml',{}).get('ddsr',False):
            maximum = max((len(label['cls']) for label in dataset.labels),default=0)
            capacity = model.model[-1].num_queries
            LOGGER.info('DDSR %s dataset: images=%d classes=%d max GT per image=%d query_capacity=%d',
                        mode,len(dataset),self.data['nc'],maximum,capacity)
            if mode == 'val' and len(dataset) < 20:
                LOGGER.warning('DDSR validation has only %d images. Verify data.yaml val and its resolved '
                               'path: %s. No split or labels were changed automatically.',len(dataset),img_path)
            expected = {"train": 1664, "val": 475}.get(mode)
            if expected is not None and len(dataset) != expected:
                LOGGER.warning("DDSR paper split expects %d %s pairs; this dataset has %d.",
                               expected, mode, len(dataset))
            if maximum > capacity:
                LOGGER.warning('DDSR query capacity cannot cover this dataset. Set p2.yaml query_capacity >= %d '
                               'and check GPU memory; valid GTs are not discarded.',maximum)
        return dataset

    def get_validator(self):
        pass

        self.loss_names = ("giou_loss", "cls_loss", "l1_loss", "density_loss") if getattr(
            de_parallel(self.model),'yaml',{}).get('ddsr',False) else ("giou_loss", "cls_loss", "l1_loss")
        return RTDETRValidator(self.test_loader, save_dir=self.save_dir, args=copy(self.args))

    def progress_string(self):
        pass
        titles = tuple('den_loss' if name == 'density_loss' else name for name in self.loss_names)
        return ('\n' + '%11s' * (4 + len(titles))) % (
            'Epoch','GPU_mem',*titles,'Instances','Size')

    def preprocess_batch(self, batch):
        pass

        batch = super().preprocess_batch(batch)
        bs = len(batch["img"])
        batch_idx = batch["batch_idx"]
        gt_bbox, gt_class = [], []
        for i in range(bs):
            gt_bbox.append(batch["bboxes"][batch_idx == i].to(batch_idx.device))
            gt_class.append(batch["cls"][batch_idx == i].to(device=batch_idx.device, dtype=torch.long))
        return batch
