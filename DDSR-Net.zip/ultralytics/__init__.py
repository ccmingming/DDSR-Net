__version__ = "8.3.13"

import os

if not os.environ.get("OMP_NUM_THREADS"):
    os.environ["OMP_NUM_THREADS"] = "1"

from ultralytics.models import RTDETR

__all__ = ("RTDETR",)
