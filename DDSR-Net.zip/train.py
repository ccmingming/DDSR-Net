import argparse
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def local_file(value):
    path = Path(value).expanduser()
    if not path.is_absolute() and not path.is_file():
        path = ROOT / path
    return path.resolve()

def validate_data(path):
    import yaml

    if not path.is_file():
        raise FileNotFoundError(f"Dataset YAML not found: {path}")
    with path.open(encoding="utf-8-sig") as stream:
        cfg = yaml.safe_load(stream)
    if not isinstance(cfg, dict):
        raise ValueError("Dataset YAML must contain a mapping")
    names = cfg.get("names")
    if not isinstance(names, (dict, list)) or not names:
        raise ValueError("Dataset YAML must contain nonempty names")
    if isinstance(names, dict):
        try:
            ids = sorted(int(key) for key in names)
        except (TypeError, ValueError):
            raise ValueError("Class IDs must be contiguous integers starting at 0")
        if ids != list(range(len(names))):
            raise ValueError("Class IDs must be contiguous integers starting at 0")
    if cfg.get("nc") is not None and int(cfg["nc"]) != len(names):
        raise ValueError("Dataset nc disagrees with the number of names")
    if not cfg.get("train") or not cfg.get("val"):
        raise ValueError("Dataset YAML must specify both train and val")
    return cfg

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data.yaml")
    parser.add_argument("--device", default="0")
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--batch", type=int, default=4)
    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--name", default="train_paper")
    parser.add_argument("--project", default=str(ROOT / "runs" / "detect"))
    parser.add_argument("--no-pretrained", dest="pretrained", action="store_false")
    parser.add_argument("--deterministic", dest="deterministic", action="store_true")
    parser.add_argument("--nondeterministic", dest="deterministic", action="store_false")
    parser.set_defaults(pretrained=True, deterministic=True)
    args = parser.parse_args()
    data_path = local_file(args.data)
    validate_data(data_path)
    if args.imgsz < 32 or args.imgsz % 32:
        raise ValueError("--imgsz must be a positive multiple of 32")
    if args.batch < 1 or args.epochs < 1 or args.workers < 0:
        raise ValueError("batch/epochs must be positive and workers must be nonnegative")
    os.chdir(ROOT)
    from ultralytics import RTDETR

    model = RTDETR(str(ROOT / "p2.yaml"))
    model.train(data=str(data_path), batch=args.batch, epochs=args.epochs,
                imgsz=args.imgsz, amp=False, workers=args.workers,
                optimizer="AdamW", lr0=2e-4, device=args.device,
                seed=args.seed, pretrained=args.pretrained,
                deterministic=args.deterministic,
                project=str(local_file(args.project)), name=args.name)

if __name__ == "__main__":
    main()
